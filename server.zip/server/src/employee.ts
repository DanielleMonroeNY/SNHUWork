import * as mongodb from "mongodb";

//Interface to be used to define the Employee Object Structure
export interface Employee {
    name: string;
    position: string;
    level: "junior" | "mid" | "senior";
    //MongoDB auto-generates _id for each newly created user
    _id?: mongodb.ObjectId;
}